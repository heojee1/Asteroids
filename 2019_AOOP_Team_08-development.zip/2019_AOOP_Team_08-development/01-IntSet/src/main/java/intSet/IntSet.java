package intSet;

import java.util.ArrayList;

/**
 * Representation of a finite set of integers.
 * 
 * @invariant getCount() >= 0
 * @invariant getCount() <= getCapacity()
 */
public class IntSet {
	private final int capacity;
	private int count;
	private ArrayList<Integer> set;

	/**
	 * Creates a new set with 0 elements.
	 * 
	 * @param capacity
	 *            the maximal number of elements this set can have
	 * @pre capacity >= 0
	 * @post getCount() == 0
	 * @post getCapacity() == capacity
	 */
	public IntSet(int capacity) {
		this.capacity = capacity;
		count = 0;
		set = new ArrayList<>(capacity);
	}

	/**
	 * Test whether the set is null.
	 *
	 * @
	 */
	public void nullSet() {
		if (set == null) {
			throw new NullPointerException("it is a null set");
		}
	}

	/**
	 * getter for set
	 *
	 * @return ArrayList set
	 */
	public ArrayList<Integer> getSet() {
		nullSet();
		return set;
	}

	/**
	 * setter for count
	 *
	 * @post getCount() == cnt
	 */
	public void setCount(int cnt) {
		nullSet();
		if (cnt <= capacity)
			count = cnt;
	}


	/**
	 * Test whether the set is empty.
	 * 
	 * @return getCount() == 0
	 */
	public boolean isEmpty() {
		nullSet();
		return set.isEmpty();
	}

	/**
	 * Test whether a value is in the set
	 * 
	 * @return exists int v in getArray() such that v == value
	 */
	public boolean has(int value) {
		nullSet();
		return set.contains(value);
	}

	/**
	 * Adds a value to the set.
	 * 
	 * @pre getCount() < getCapacity()
	 * @post has(value)
	 * @post !this@pre.has(value) implies (getCount() == this@pre.getCount() + 1)
	 * @post this@pre.has(value) implies (getCount() == this@pre.getCount())
	 */
	public void add(int value) {
		nullSet();
		if (count < capacity && !set.contains(value)) {
			set.add(value);
			count++;
		}
	}

	/**
	 * Removes a value from the set.
	 * 
	 * @post !has(value)
	 * @post this@pre.has(value) implies (getCount() == this@pre.getCount() - 1)
	 * @post !this@pre.has(value) implies (getCount() == this@pre.getCount())
	 */
	public void remove(int value) {
		nullSet();
		if (set.contains(value)) {
			set.remove(new Integer(value));
			count--;
		}
	}

	/**
	 * Returns the intersection of this set and another set.
	 * 
	 * @param other
	 *            the set to intersect this set with
	 * @return the intersection
	 * @pre other != null
	 * @post forall int v: (has(v) and other.has(v)) implies return.has(v)
	 * @post forall int v: return.has(v) implies (has(v) and other.has(v))
	 */
	public IntSet intersect(IntSet other) {
		nullSet();
		other.nullSet();
		int maxCapacity = count > other.getCount() ? count : other.getCount();
		IntSet returnSet = new IntSet(maxCapacity);
		for (int i : other.set) {
			if (this.has(i)) returnSet.add(i);
		}
		return returnSet;
	}

	/**
	 * Returns the union of this set and another set.
	 * 
	 * @param other
	 *            the set to union this set with
	 * @return the union
	 * @pre other != null
	 * @post forall int v: has(v) implies return.has(v)
	 * @post forall int v: other.has(v) implies return.has(v)
	 * @post forall int v: return.has(v) implies (has(v) or other.has(v))
	 */
	public IntSet union(IntSet other) {
		nullSet();
		other.nullSet();
		int maxCapacity = count + other.getCount();
		IntSet returnSet = new IntSet(maxCapacity);
		for (int i : set) {
			returnSet.add(i);
		}
		for (int i : other.set) {
			returnSet.add(i);
		}
		return returnSet;
	}

	/**
	 *
	 * @param other
	 * 				the set to union this set with
	 * @return the difference
	 * @pre other != null
	 * @post forall int v: other.has(v) implies !return.has(v)
	 * @post forall int v: return.has(v) implies (has(v) and !other.has(v))
	 */
	public IntSet difference(IntSet other) {
		nullSet();
		other.nullSet();
		IntSet returnSet = new IntSet(count);
		for (int i : set) {
			if (!other.has(i)) returnSet.add(i);
		}
		return returnSet;
	}

	/**
	 *
	 * @param other
	 * 				the set to union this set with
	 * @return the symmetric difference
	 * @pre other != null
	 * @post forall int v: (has(v) and other.has(v)) implies !return.has(v)
	 * @post forall int v: return.has(v) implies (has(v) xor other.has(v))
	 */
	public IntSet symmetricDiff(IntSet other) {
		nullSet();
		other.nullSet();
		IntSet union = this.union(other);
		IntSet intersect = this.intersect(other);
		return union.difference(intersect);
	}


	/**
	 * Returns a representation of this set as an array
	 * 
	 * @post return.length == getCount()
	 * @post forall int v in return: has(v)
	 */
	public int[] getArray() {
		nullSet();
		//throw new UnsupportedOperationException ("not yet implemented") ;
		int[] returnArray = new int[count];
		for (int idx = 0; idx < count ; idx++) {
			returnArray[idx] = set.get(idx);
		}
		return returnArray;
	}

	/**
	 * Returns the number of elements in the set.
	 */
	public int getCount() {
		nullSet();
		return count;
	}

	/**
	 * Returns the maximal number of elements in the set.
	 */
	public int getCapacity() {
		nullSet();
		return capacity;
	}

	/**
	 * Returns a string representation of the set. The empty set is represented
	 * as {}, a singleton set as {x}, a set with more than one element like {x,
	 * y, z}.
	 */
	public String toString() {
		nullSet();
		StringBuilder sb = new StringBuilder("{");
		for (int idx = 0; idx < count; idx++) {
			sb.append(set.get(idx));
			if (idx < count - 1) sb.append(", ");
		}
		sb.append("}");
		return sb.toString();
	}

}
