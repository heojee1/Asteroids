package intSet;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.ArrayList;

import static org.junit.Assert.*;

/**
 * This is a dummy class. Feel free to delete it and generate your own using JUnit.
 * Important: make sure to fix your package directory yourself if you delete this!
 */
public class IntSetTest {
    private IntSet set0;
    private IntSet set1;
    private IntSet set2;
    private IntSet set3;
    private IntSet set4;
    private IntSet set5;
    private IntSet set6;
    private IntSet set7;
    private IntSet set8;


    @Before
    public void setUp() {

        set1 = new IntSet(0); // count 0, cap 0

        set2 = new IntSet(1); // count 0 , cap 1

        set3 = new IntSet(3);
        Collections.addAll(set3.getSet(), 1, 3, 5); // count 3, cap 3
        set3.setCount(3);

        set4 = new IntSet(5);
        Collections.addAll(set4.getSet(), 0, 2, 4, 6); // count 4, cap 5
        set4.setCount(4);

        set5 = new IntSet(7);
        Collections.addAll(set5.getSet(), 1, 2, 3, 5, 7, 9, 71); // count 7, cap 7
        set5.setCount(7);

        set6 = new IntSet(10);
        Collections.addAll(set6.getSet(), 0, 4, 5, 8, 11, 16, 100); // count 7, cap 10
        set6.setCount(7);

        set7 = new IntSet(7);
        Collections.addAll(set7.getSet(), 0, 4, 5, 8, 11, 16, 100); // count 7, cap 7
        set7.setCount(7);

        set8 = new IntSet(4);
        Collections.addAll(set8.getSet(),0, 4, 5); // count 3, cap 4
        set8.setCount(3);
    }

    @Test
    public void testConstructor() {
        assertEquals(0, set1.getCapacity());
        assertEquals(0, set1.getCount());

        assertEquals(1, set2.getCapacity());
        assertEquals(0, set2.getCount());

        assertEquals(10, set6.getCapacity());
        assertEquals(7, set6.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void testNullSet() {
        set0.isEmpty();
        set0.has(0);
        set0.add(1);
        set0.remove(2);
        set0.intersect(set1);
        set0.union(set1);
        set0.difference(set2);
        set0.symmetricDiff(set2);
        set0.getCount();
        set0.getCapacity();
        set0.toString();

    }


    @Test
    public void testIsEmpty() {
        assertTrue(set1.isEmpty());
        assertTrue(set2.isEmpty());
        assertFalse(set3.isEmpty());
        assertFalse(set4.isEmpty());
        assertFalse(set5.isEmpty());
        assertFalse(set6.isEmpty());

    }

    @Test
    public void testHas() {
        assertFalse(set2.has(0));
        assertTrue(set3.has(1));
        assertFalse(set3.has(2));
        assertTrue(set4.has(6));
        assertFalse(set4.has(1));
        assertTrue(set5.has(1));
        assertFalse(set5.has(0));
        assertFalse(set6.has(101));
    }

    @Test
    public void testAdd() {
        /*
        count == capacity
         */
        set3.add(7);
        assertEquals(Arrays.asList(1, 3, 5), set3.getSet());
        assertEquals(3, set3.getCount());

        /*
        value already exists
         */
        set4.add(0);
        assertEquals(Arrays.asList(0, 2, 4, 6), set4.getSet());
        assertEquals(4, set4.getCount());

        /*
        legal addition
         */
        set6.add(88);
        assertEquals(Arrays.asList(0, 4, 5, 8, 11, 16, 100, 88), set6.getSet());
        assertEquals(8, set6.getCount());
    }

    @Test
    public void testRemove() {
        /*
         no matching value
         */
        set5.remove(4);
        assertEquals(Arrays.asList(1, 2, 3, 5, 7, 9, 71), set5.getSet());
        assertEquals(7, set5.getCount());

        /*
        no matching value (empty set)
         */
        set1.remove(1);
        assertEquals(Collections.emptyList(), set1.getSet());
        assertEquals(0, set1.getCount());

        /*
        legal removal
         */
        set5.remove(71);
        assertEquals(Arrays.asList(1, 2, 3, 5, 7, 9), set5.getSet());
        assertEquals(6, set5.getCount());
    }

    @Test
    public void testIntersect() {
        /*
        sets with same content
         */
        assertEquals(Arrays.asList(0, 4, 5, 8, 11, 16, 100), set6.intersect(set7).getSet());
        assertEquals(Arrays.asList(0, 4, 5, 8, 11, 16, 100), set7.intersect(set6).getSet());

        /*
        intersection with subset
         */
        assertEquals(Arrays.asList(0, 4, 5), set6.intersect(set8).getSet());
        assertEquals(Arrays.asList(0, 4, 5), set8.intersect(set6).getSet());

        /*
        empty set & empty set
         */
        assertEquals(Collections.emptyList(), set2.intersect(set1).getSet());
        assertEquals(Collections.emptyList(), set1.intersect(set2).getSet());

        /*
        empty set & non-empty set
         */
        assertEquals(Collections.emptyList(), set1.intersect(set3).getSet());
        assertEquals(Collections.emptyList(), set3.intersect(set1).getSet());

        /*
         non-empty set & non-empty set
         */
        assertEquals(Arrays.asList(0, 4), set4.intersect(set6).getSet());
        assertEquals(Arrays.asList(0, 4), set6.intersect(set4).getSet());

        /*
         no intersection
         */
        assertEquals(Collections.emptyList(), set3.intersect(set4).getSet());
        assertEquals(Collections.emptyList(), set4.intersect(set3).getSet());

    }

    @Test
    public void testUnion() {
        /*
        union with subset
         */
        assertEquals(Arrays.asList(0, 4, 5, 8, 11, 16, 100), set6.union(set8).getSet());

        /*
        empty set & empty set
         */
        assertEquals(Collections.emptyList(), set1.union(set2).getSet());

        /*
        empty set & non-empty set
         */
        assertEquals(Arrays.asList(1, 3, 5), set1.union(set3).getSet());

        /*
        non-empty set & non-empty set
         */
        assertEquals(Arrays.asList(0, 2, 4, 6, 1, 3, 5, 7, 9, 71), set4.union(set5).getSet());
    }

    @Test
    public void testDifference() {
        /*
        set - subset
         */
        assertEquals(Arrays.asList(8, 11, 16, 100), set6.difference(set8).getSet());

        /*
        subset-set
         */
        assertEquals(Collections.emptyList(), set8.difference(set6).getSet());

        /*
        empty set - empty set
         */
        assertEquals(Collections.emptyList(), set1.difference(set2).getSet());

        /*
        empty set - non-empty set
         */
        assertEquals(Collections.emptyList(), set2.difference(set3).getSet());

        /*
        non-empty set - empty set
         */
        assertEquals(Arrays.asList(1, 2, 3, 5, 7, 9, 71), set5.difference(set2).getSet());

        /*
        non-empty set - non-empty set
         */
        assertEquals(Arrays.asList(2, 6), set4.difference(set6).getSet());

        /*
        non-empty set - non-empty set (no same element)
         */
        assertEquals(Arrays.asList(1, 3, 5), set3.difference(set4).getSet());

    }

    @Test
    public void testSymmetricDiff() {
        /*
        set & subset
         */
        assertEquals(Arrays.asList(8, 11, 16, 100), set6.symmetricDiff(set8).getSet());

        /*
        empty set & empty set
         */
        assertEquals(Collections.emptyList(), set1.symmetricDiff(set2).getSet());

        /*
        empty set & non-empty set
         */
        assertEquals(Arrays.asList(1, 2, 3, 5, 7, 9, 71), set5.symmetricDiff(set1).getSet());

        /*
        non-empty set & non-empty set
         */
        assertEquals(Arrays.asList(5, 8, 11, 16, 100, 2, 6), set6.symmetricDiff(set4).getSet());


        /*
        non-empty set - non-empty set (no same element)
         */
        assertEquals(Arrays.asList(1, 3, 5, 0, 2, 4, 6), set3.symmetricDiff(set4).getSet());
    }

    @Test
    public void testGetArray() {
        assertArrayEquals(new int[] {}, set1.getArray());
        assertEquals(set1.getCount(), set1.getArray().length);

        assertArrayEquals(new int[] {}, set2.getArray());
        assertEquals(set2.getCount(), set2.getArray().length);

        assertArrayEquals(new int[] {1, 3, 5}, set3.getArray());
        assertEquals(set3.getCount(), set3.getArray().length);

        assertArrayEquals(new int[] {0, 2, 4, 6}, set4.getArray());
        assertEquals(set4.getCount(), set4.getArray().length);

        assertArrayEquals(new int[] {1, 2, 3, 5, 7, 9, 71}, set5.getArray());
        assertEquals(set5.getCount(), set5.getArray().length);

        assertArrayEquals(new int[] {0, 4, 5, 8, 11, 16, 100}, set6.getArray());
        assertEquals(set6.getCount(), set6.getArray().length);

    }

    @Test
    public void testGetCount() {
        assertEquals(0, set1.getCount());
        assertEquals(0, set2.getCount());
        assertEquals(3, set3.getCount());
        assertEquals(4, set4.getCount());
        assertEquals(7, set5.getCount());
        assertEquals(7, set6.getCount());
    }

    @Test
    public void testGetCapacity() {
        assertEquals(0, set1.getCapacity());
        assertEquals(1, set2.getCapacity());
        assertEquals(3, set3.getCapacity());
        assertEquals(5, set4.getCapacity());
        assertEquals(7, set5.getCapacity());
        assertEquals(10, set6.getCapacity());
    }

    @Test
    public void testToString() {
        assertEquals("{}", set1.toString());
        assertEquals("{}", set2.toString());
        assertEquals("{1, 3, 5}", set3.toString());
        assertEquals("{0, 2, 4, 6}", set4.toString());
        assertEquals("{1, 2, 3, 5, 7, 9, 71}", set5.toString());
        assertEquals("{0, 4, 5, 8, 11, 16, 100}", set6.toString());
    }

    @Test
    public void testGetSet() {
        assertEquals(Arrays.asList(0, 2, 4, 6), set4.getSet());
        assertEquals(Arrays.asList(1, 2, 3, 5, 7, 9, 71), set5.getSet());
    }

    @Test
    public void testSetCount() {
        set2.setCount(1);
        assertEquals(1, set2.getCount());

        set4.setCount(3);
        assertEquals(3, set4.getCount());
    }
}
