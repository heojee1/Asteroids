# Assignment 2 - Read this before you begin!

For this assignment, please choose one of the three available assignments to complete:

*  Chat
*  Cats
*  Factory

For whichever assignment you choose, please note that Javadoc comments are *required*, as is testing for public methods. These restrictions do not apply to one-line getters and setters, but for anything else, please do add comments and testing.