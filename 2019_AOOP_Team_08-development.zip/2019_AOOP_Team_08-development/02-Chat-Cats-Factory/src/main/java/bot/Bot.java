package bot;

import util.Utility;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;
import static java.lang.Thread.sleep;

/**
 * Bot is a participant of the chat. It connects to a ChatRoom to communicate with other participating Bots.
 */
public class Bot extends JFrame {
    private InetAddress IPAddress;
    private int chatRoomPortNumber;
    private Socket socket;
    private String name;
    private ArrayList<Integer> chatRooms;
    private static ArrayList<String> words;
    private boolean changed = false;
    private TextArea textArea;

    /**
     * creates a new LocalBot object
     * @param IPAddress IP address of the server
     * @param chatRoomPortNumber port number of the chatRoom
     * @param name name of the Bot
     */
    public Bot(InetAddress IPAddress, int chatRoomPortNumber, String name) {
        this.IPAddress = IPAddress;
        this.chatRoomPortNumber = chatRoomPortNumber;
        this.name = name;
        chatRooms = new ArrayList<>();
        Collections.addAll(chatRooms, 7001, 7002, 7003, 7004);
        words = new ArrayList<>();
        setUpUI();
    }

    /**
     * set up User Interface
     */
    private void setUpUI() {
        setTitle(name + " at " + chatRoomPortNumber);
        textArea = new TextArea();
        textArea.setEditable(false);
        textArea.setBackground(new Color(0x9BCF99));
        getContentPane().add(textArea);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                stopBot();
            }
        });
        setPreferredSize(new Dimension(400, 300));
        pack();
        Random random = new Random();
        int randomInt = random.nextInt(10);
        setLocation(randomInt*100,350);
        setVisible(true);
    }

    /**
     * getter for InetAddress serverIP
     *
     * @return serverIP
     */
    public InetAddress getIPAddress() {
        return IPAddress;
    }

    /**
     * getter for Socket socket
     *
     * @return socket
     */
    public Socket getSocket() {
        return socket;
    }

    /**
     * getter for int chatRoomPortNumber
     * @return chatRoomPortNumber
     */
    public int getChatRoomPortNumber() {
        return chatRoomPortNumber;
    }

    /**
     * getter for ArrayList words
     *
     * @return words
     */
    public ArrayList<String> getWords() {
        return words;
    }

    /**
     * getter for ArrayList chatRooms
     *
     * @return chatRooms
     */
    public ArrayList<Integer> getChatRooms() {
        return chatRooms;
    }

    /**
     * getter for TextArea textArea
     *
     * @return textArea
     */
    public TextArea getTextArea() {
        return textArea;
    }

    /**
     * setter for int chatRoomPortNumber
     * @param newPortNumber wanted value of chatRoomPortNumber
     */
    public void setChatRoomPortNumber(int newPortNumber) {
        chatRoomPortNumber = newPortNumber;
    }

    /**
     * setter for boolean changed
     * @param newChanged wanted value of changed
     */
    public void setChanged(boolean newChanged) {
        changed = newChanged;
    }

    /**
     * connects the Bot to the ChatRoom
     * @param IP IP address of the ChatRoom
     * @param portNumber port number of the ChatRoom
     */
    public void connectToChatRoom(InetAddress IP, int portNumber) {
        try {
            socket = new Socket(IP, portNumber);
            String info = "[connected to chatroom]\n";
            textArea.append(info);
        } catch (IOException e) {
            textArea.append("[connection fail]\n");
            stopBot();
        }
    }

    /**
     * starts the Bot.
     * begins conversation (communication between participating Bots)
     */
    public void startBot() {
        Thread thread = new Thread(() -> {
            connectToChatRoom(IPAddress, chatRoomPortNumber);
            String info = socket.getLocalAddress().toString() + socket.getLocalSocketAddress().toString() + "\n";
            textArea.append(info);
            send(name);
            send();
            receive();
        });
        thread.start();
    }

    /**
     * receives messages from the ChatRoom, which originally are from participating Bots
     */
    public void receive() {
        while (!changed) {
            try {
                String message = Utility.codeInput(socket);
                textArea.append(message);
                StringBuilder sb = new StringBuilder();
                boolean name = true;
                for (int i = 0; i < message.length(); i++) {
                    if (!name) sb.append(message.charAt(i));
                    if (message.charAt(i) == ':') name = false;
                }
                updateWords(sb.toString());
            } catch (IOException e) {
                stopBot();
                break;
            }
        }
    }

    /**
     * sends messages to the Server, which will be forwarded to participating Bots
     * @param message message to be sent
     */
    public void updateWords(String message) {
        StringTokenizer st = new StringTokenizer(message);
        while (st.hasMoreTokens()) {
            String word = st.nextToken();
            if (words.size() < 40)
                words.add(word);
            else {
                words.remove(0);
                words.add(word);
            }
        }
    }

    /**
     * sends messages to the ChatRoom, which will be forwarded to participating Bots
     * @param message message to be sent
     */
    public void send(String message) {
        Thread thread = new Thread(() -> {
            try {
                Utility.codeOutput(socket, message);
            } catch (IOException e) {
                stopBot();
            }
        });
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            stopBot();
        }
    }

    /**
     * build new messages and send to participating Bots
     */
    public void send() {
        Thread thread = new Thread(() -> {
            while (!changed) {
                try {
                    sleep(7000);
                    String message = buildMessage();
                    Utility.codeOutput(socket, message);
                } catch (IOException e) {
                    stopBot();
                } catch (InterruptedException e) {
                    stopBot();
                }
            }
        });
        thread.start();
    }

    /**
     * builds new message from words in ArrayList words in random manner
     * @return newly built message
     */
    public String buildMessage() {
        Random random = new Random();
        int length = random.nextInt(7);
        StringBuilder sb = new StringBuilder();
        while (!words.isEmpty() && length >= 0) {
            int idx = random.nextInt(words.size());
            sb.append(words.get(idx) + " ");
            length--;
        }
        sb.append("\n");
        return sb.toString();
    }

    /**
     * stops the Bot in case of errors/exceptions
     * closes socket and,or disposes frame
     */
    public void stopBot() {
        try {
            if (socket!=null && !socket.isClosed()) {
                send("[" + name + " disconnected]\n");
                socket.close();
            } else if (socket == null) {
                dispose();
            }
        } catch (IOException e) {}
    }

    /**
     * reads words from File file and saves in ArrayList words
     */
    public void readTextFile(File file) {
        try{
            BufferedReader bufReader = new BufferedReader(new FileReader(file));
            String word = "";
            while((word = bufReader.readLine()) != null){
                words.add(word);
            }
            bufReader.close();
        } catch (FileNotFoundException e) {
            textArea.append("[unable to read text file]");
        } catch (IOException e) {
            textArea.append("[error reading text file]");
        }
    }

    /**
     * drive code that runs client(Bot)-side program
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("IP address: ");
        InetAddress IPAddress;
        try {
            IPAddress = InetAddress.getByName(sc.nextLine());
        } catch (UnknownHostException e) {
            System.out.println("wrong IP type");
            return;
        }

        System.out.print("chat room port: ");
        int chatRoomPortNumber = sc.nextInt();
        sc.skip("\n");

        System.out.print("bot name: ");
        String name  = sc.nextLine();

        System.out.print("text file path : ");
        File file = new File(sc.nextLine());

        System.out.print("local type 0, free type 1: ");
        int type = sc.nextInt();
        
        if (type == 1) {
            FreeBot bot = new FreeBot(IPAddress, chatRoomPortNumber, name);
            bot.startBot();
            bot.changeChatRoom();
            bot.readTextFile(file);
        } else if (type == 0) {
            LocalBot bot = new LocalBot(IPAddress, chatRoomPortNumber, name);
            bot.startBot();
            bot.readTextFile(file);
        }
    }


}
