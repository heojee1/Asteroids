package bot;

import javax.imageio.IIOParam;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.Random;


/**
 * FreeBot is a type of Bot that can connect to a random server at random moment
 */
public class FreeBot extends Bot {
    /**
     * creates a new LocalBot object
     *
     * @param IPAddress          IP address of the server
     * @param chatRoomPortNumber port number of the chatRoom
     * @param name               name of the Bot
     */
    public FreeBot(InetAddress IPAddress, int chatRoomPortNumber, String name) {
        super(IPAddress, chatRoomPortNumber, name);
    }

    /**
     * picks a random port number from ArrayList chatRooms
     *
     * @return randomly selected int port number
     */
    public int randomPort() {
        Random random = new Random();
        int newPortNum = getChatRoomPortNumber();
        while (newPortNum == getChatRoomPortNumber()) {
            int idx = random.nextInt(getChatRooms().size());
            newPortNum = getChatRooms().get(idx);
        }
        return newPortNum;
    }

    /**
     * changes to a different ChatRoom
     */
    /*
    public void changeChatRoom() {
        Thread thread = new Thread(() -> {
            while (true) {
                int newPortNumber = randomPort();
                setChanged(false);
                setChatRoomPortNumber(newPortNumber);
                connectToChatRoom(getIPAddress(), newPortNumber);
                setTitle(getName() + " at " + getChatRoomPortNumber());
                getTextArea().setText("");
                setChanged(true);
                send(getName());
                send();
                receive();
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

     */
    /**
     * changes to random different server at random time.
     */
    public void changeChatRoom() {
        Thread thread = new Thread(() -> {
            while(true) {
                try {
                    Thread.sleep(10000); /** change this to random **/
                    int newPortNumber = randomPort();
                    FreeBot bot = new FreeBot(getIPAddress(), getChatRoomPortNumber(), getName());
                    stopBot();
                    bot.startBot();
                } catch (InterruptedException e) {
                    stopBot();
                }
            }
        });
        thread.start();
    }
}


