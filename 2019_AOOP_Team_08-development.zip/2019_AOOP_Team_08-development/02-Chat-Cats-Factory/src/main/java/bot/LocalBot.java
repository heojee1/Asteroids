package bot;

import java.io.File;
import java.net.InetAddress;

/**
 * LocalBot is a type of Bot that once connected to a server, never leaves the server
 */
public class LocalBot extends Bot {

    /**
     * creates a new LocalBot object
     *
     * @param IPAddress          IP address of the server
     * @param chatRoomPortNumber port number of the chatRoom
     * @param name               name of the Bot
     */
    public LocalBot(InetAddress IPAddress, int chatRoomPortNumber, String name) {
        super(IPAddress, chatRoomPortNumber, name);
    }
}
