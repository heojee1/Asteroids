package server;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ChatRoom is a host to the bots. It manages the connections between the bots and itself
 */
public class ChatRoom extends JFrame {
    private int chatRoomPortNum;
    private Server server;
    private ServerSocket serverSocket;
    private ExecutorService executor;
    private ArrayList<ChatRoomHandler> handlers;
    private TextArea textArea;

    /**
     * creates a new ChatRoom object
     * @param chatRoomPortNum port number of the ChatRoom
     * @param server Server hosting the ChatRoom
     */
    public ChatRoom(int chatRoomPortNum, Server server) {
        this.chatRoomPortNum = chatRoomPortNum;
        this.server = server;
        handlers = new ArrayList<>();
        setUpUI();
    }

    /**
     * set up User Interface
     */
    private void setUpUI() {
        setTitle("Room " + chatRoomPortNum);
        textArea = new TextArea();
        textArea.setEditable(false);
        textArea.setBackground(new Color(0xCFABAD));
        getContentPane().add(textArea);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                stopChatRoom();
            }
        });
        setPreferredSize(new Dimension(300, 300));
        pack();
        Random random = new Random();
        int randomInt = random.nextInt(80);
        setLocation(randomInt*10,80);
        setVisible(true);
    }

    /**
     * getter for ExecutorService executor
     *
     * @return executor
     */
    public ExecutorService getExecutor() {
        return executor;
    }

    /**
     * getter for TextArea textArea
     *
     * @return textArea
     */
    public TextArea getTextArea() {
        return textArea;
    }

    /**
     * getter for ArrayList handlers
     *
     * @return handlers
     */
    public ArrayList<ChatRoomHandler> getHandlers() {
        return handlers;
    }

    /**
     * adds given Handler to ArrayList handlers
     *
     * @param handler Handler to be added
     */
    synchronized public void addHandler(ChatRoomHandler handler) {
        handlers.add(handler);
    }

    /**
     * removes given Handler from ArrayList handlers
     *
     * @param handler Handler to be removed
     */
    synchronized public void removeHandler(ChatRoomHandler handler) {
        handlers.remove(handler);
    }

    /**
     * accepts connections from Bots.
     * creates a corresponding ChatRoomHandler
     */
    public void acceptConnections() {
        Runnable runnable = () -> {
            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    String message = "[connected with " + socket.getRemoteSocketAddress() + "]\n";
                    textArea.append(message);
                    ChatRoomHandler handler = new ChatRoomHandler(socket, this);
                    addHandler(handler);
                } catch (IOException e) {
                    String message = "[connection fail with " + Thread.currentThread().getName() + "]\n";
                    textArea.append(message);
                    if(!serverSocket.isClosed()) {
                        stopChatRoom();
                    }
                    break;
                }
            }
        };
        executor.submit(runnable);
    }

    /**
     * starts the ChatRoom
     * create serverSocket and accepts connections
     */
    public void startChatRoom() {
        try {
            executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());
            serverSocket = new ServerSocket(chatRoomPortNum);
            server.addChatRoom(this);
            String info = "[room address: " + serverSocket.getInetAddress() + "]\n" + "[room port: " + serverSocket.getLocalPort() + "]\n";
            textArea.append(info);
        } catch (IOException e) {
            stopChatRoom();
        }
        acceptConnections();
    }

    /**
     * stops the ChatRoom in case of errors/exceptions
     */
    public void stopChatRoom() {
        try {
            server.removeChatRoom(this);
            for (ChatRoomHandler handler : handlers) {
                handler.sendToBots("[chatroom shutdown]");
                removeHandler(handler);
            }
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
            if (serverSocket != null && !executor.isShutdown()) {
                executor.shutdown();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}

