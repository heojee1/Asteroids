package server;

import util.Utility;

import java.io.IOException;
import java.net.Socket;

/**
 * ChatRoomHandler controls the communications between host chatRoom and one of its participating bots
 * it handles sending and receiving data to and from the participant
 */
public class ChatRoomHandler {
    private Socket socket;
    private ChatRoom chatRoom;

    /**
     * creates a new ChatRoomHandler object
     * @param socket Socket of the connected Bot
     * @param chatRoom ChatRoom connected to the Bot
     */
    public ChatRoomHandler(Socket socket, ChatRoom chatRoom) {
        this.socket = socket;
        this.chatRoom = chatRoom;
        receiveFromBot();
    }

    /**
     * receives message from the Bot and sends to all participating Bots.
     * announces the connection of the Bot
     */
    public void receiveFromBot() {
        Runnable runnable = () -> {
            try {
                String name = Utility.codeInput(socket);
                for (ChatRoomHandler handler : chatRoom.getHandlers()) {
                    if (handler != this) handler.sendToBots("-----------" + name + " has connected-----------\n");
                    else handler.sendToBots("-----------" + "you've been connected-----------\n");
                }
                while (true) {
                    String message = name + ": " + Utility.codeInput(socket);
                    for (ChatRoomHandler handler : chatRoom.getHandlers()) {
                        handler.sendToBots(message);
                    }
                }
            } catch (IOException e) {
                removeHandler();
            }
        };
        chatRoom.getExecutor().submit(runnable);
    }

    /**
     * sends the given message to all participating Bots
     *
     * @param message the data to be sent out
     */
    public void sendToBots(String message) {
        Runnable runnable = () -> {
            try {
                Utility.codeOutput(socket, message);
            } catch (IOException e) {
                removeHandler();
            }
        };
        chatRoom.getExecutor().submit(runnable);
    }

    /**
     * shuts down in case of errors/exceptions
     */
    public void removeHandler() {
        try {
            chatRoom.removeHandler(this);
            chatRoom.getTextArea().append("[no connection with " + socket.getInetAddress() + " ]\n");
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
