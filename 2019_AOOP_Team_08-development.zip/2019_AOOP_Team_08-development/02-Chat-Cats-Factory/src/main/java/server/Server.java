package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Observable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Server is a host to the chat program. It contains information of multiple ChatRooms.
 * It sets up the ChatRooms and accpet connections from Bots
 */
public class Server {
    private static ArrayList<ChatRoom> chatRooms = new ArrayList<>();
    private static ChatRoom chatRoom1;
    private static ChatRoom chatRoom2;
    private static ChatRoom chatRoom3;
    private static ChatRoom chatRoom4;

    /**
     * getter for ArrayList chatRooms
     *
     * @return chatRooms
     */
    public ArrayList<ChatRoom> getChatRooms() {
        return chatRooms;
    }

    /**
     * adds given ChatRoom to ArrayList chatRooms
     *
     * @param chatRoom a ChatRoom object to be added
     */
    synchronized public void addChatRoom(ChatRoom chatRoom) {
        chatRooms.add(chatRoom);
    }

    /**
     * removes given ChatRoom from ArrayList chatRooms
     *
     * @param chatRoom a ChatRoom object to be removed
     */
    synchronized public void removeChatRoom(ChatRoom chatRoom) {
        chatRooms.remove(chatRoom);
    }

    /**
     * creates four new ChatRoom objects and runs them
     */
    public void startServer() {
        chatRoom1 = new ChatRoom(7001, this);
        chatRoom2 = new ChatRoom(7002, this);
        chatRoom3 = new ChatRoom(7003, this);
        chatRoom4 = new ChatRoom(7004, this);
        chatRoom1.startChatRoom();
        chatRoom2.startChatRoom();
        chatRoom3.startChatRoom();
        chatRoom4.startChatRoom();
    }

    /**
     * drive code that runs server-side program
     */
    public static void main (String[] args) {
        Server server = new Server();
        server.startServer();
    }
}
