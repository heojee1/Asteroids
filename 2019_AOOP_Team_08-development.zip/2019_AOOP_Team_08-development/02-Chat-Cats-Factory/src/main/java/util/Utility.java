package util;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Utility contains static methods that are used by both bot and server packages.
 */
public final class Utility {

    /**
     * reads input from the given socket as bytes,
     * process and return the array of bytes as string
     *
     * @param socket the socket from which it will read input
     * @return a string that has been read
     * @throws IOException if the input cannot be encoded to bytes, or socket's InputStream face error
     */
    public static String codeInput(Socket socket) throws IOException {
        byte[] byteArr = new byte[100];
        InputStream in = socket.getInputStream();
        int readByteCount = in.read(byteArr);
        if(readByteCount == -1) throw new IOException();
        return new String(byteArr, 0, readByteCount, "UTF-8");
    }

    /**
     * turns a given String of message into array of bytes,
     * send it out through the OutputStream of the given socket
     *
     * @param socket the socket from which the output will be sent out
     * @param message String of message that will be sent out
     * @throws IOException if the message cannot be encoded to bytes, or socket's OutputStream face error
     */
    public static void codeOutput(Socket socket, String message) throws IOException {
        byte[] byteArr = message.getBytes("UTF-8");
        OutputStream out = socket.getOutputStream();
        out.write(byteArr);
        out.flush();
    }
}
