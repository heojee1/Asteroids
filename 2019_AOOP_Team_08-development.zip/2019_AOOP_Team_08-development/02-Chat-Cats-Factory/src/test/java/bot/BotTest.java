package bot;

import org.junit.Test;
import server.ChatRoom;
import server.Server;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.StringTokenizer;

import static org.junit.Assert.*;

public class BotTest {

    @Test
    public void setChatRoomPortNumber() throws UnknownHostException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Bot bot = new Bot(IPAddress, 8000, "bot");
        bot.setChatRoomPortNumber(7000);
        assertEquals(7000, bot.getChatRoomPortNumber());
    }

    @Test
    public void connectToChatRoom() throws IOException, InterruptedException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(8001, server);
        c1.startChatRoom();
        Bot bot1 = new Bot(IPAddress, 8001, "bot");
        bot1.connectToChatRoom(IPAddress, 8001);
        Thread.sleep(1000);
        assertEquals(1, c1.getHandlers().size());
    }

    @Test
    public void startBot() throws InterruptedException, UnknownHostException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(8002, server);
        c1.startChatRoom();
        File file = new File(System.getProperty("user.dir")+"/t.txt/");
        Bot bot1 = new Bot(IPAddress, 8002, "bot");
        bot1.startBot();
        Thread.sleep(1000);
        assertEquals(1, c1.getHandlers().size());
    }

    @Test
    public void updateWords() throws UnknownHostException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Bot bot = new Bot(IPAddress, 8002, "bot");
        bot.updateWords("Hello everyone sky is blue");
        assertEquals(Arrays.asList("Hello", "everyone", "sky", "is", "blue"), bot.getWords());
    }

    @Test
    public void buildMessage() throws UnknownHostException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");

        Bot bot1 = new Bot(IPAddress, 8002, "bot");
        Collections.addAll(bot1.getWords(), "h", "aa", "cc", "bbb", "dd");
        String str1 = bot1.buildMessage();
        StringTokenizer st1 = new StringTokenizer(str1);
        int len1 = 0;
        while(st1.hasMoreTokens()) {
            len1++;
            assertTrue(bot1.getWords().contains(st1.nextToken()));
        }
        assertTrue(len1 <= 8);

        Bot bot2 = new Bot(IPAddress, 8002, "bot");
        String str2 = bot2.buildMessage();
        StringTokenizer st2 = new StringTokenizer(str2);
        int len2 = 0;
        while(st2.hasMoreTokens()) {
            len2++;
            assertTrue(bot1.getWords().contains(st2.nextToken()));
        }
        assertTrue(len2 <= 8);
    }

    @Test
    public void stopBot() throws UnknownHostException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Bot bot1 = new Bot(IPAddress, 8002, "bot");
        bot1.stopBot();
        assertTrue(bot1.getSocket().isClosed());

        Bot bot2 = new Bot(IPAddress, 8002, "bot");
        bot2.stopBot();
        assertTrue(bot2.getSocket().isClosed());
    }

    @Test
    public void readTextFile() throws UnknownHostException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        File file = new File(System.getProperty("user.dir")+"/t.txt/");
        Bot bot1 = new Bot(IPAddress, 8002, "bot");
        bot1.readTextFile(file);
        assertEquals(Arrays.asList("autumn", "spring", "winter", "summer"), bot1.getWords());

    }
}