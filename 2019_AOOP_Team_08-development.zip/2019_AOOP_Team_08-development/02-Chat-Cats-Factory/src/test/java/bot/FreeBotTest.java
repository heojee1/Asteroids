package bot;

import org.junit.Test;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Random;

import static org.junit.Assert.*;

public class FreeBotTest {

    @Test
    public void randomPort() throws UnknownHostException {
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        FreeBot bot = new FreeBot(IPAddress, 7001, "bot");
        int newPort = bot.randomPort();
        assertTrue(newPort != bot.getChatRoomPortNumber() && bot.getChatRooms().contains(newPort));
    }
}