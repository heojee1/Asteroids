package server;

import org.junit.Test;

import java.io.IOException;

public class ChatRoomHandlerTest {

    @Test
    public void receiveFromBot() throws IOException {
        /*
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(5001, server);
        Socket socket = new Socket("localhost", 5002);
        ChatRoomHandler handler = new ChatRoomHandler(socket, c1);
        OutputStream out = socket.getOutputStream();
        handler.receiveFromBot();

         */

    }

    @Test
    public void sendToBots() {
    }

    @Test
    public void removeHandler() {
    }
}