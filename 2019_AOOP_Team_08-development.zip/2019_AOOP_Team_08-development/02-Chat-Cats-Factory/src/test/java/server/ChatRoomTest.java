package server;

import org.junit.Test;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Arrays;
import java.util.HashMap;

import static org.junit.Assert.*;

public class ChatRoomTest {

    @Test
    public void addHandler() throws IOException, InterruptedException {
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(5001, server);
        c1.startChatRoom();
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Socket socket1 = new Socket(IPAddress, 5001);
        Socket socket2 = new Socket(IPAddress, 5001);
        Thread.sleep(500);
        assertEquals(2, c1.getHandlers().size());
        socket1.close();
        socket2.close();
    }

    @Test
    public void removeHandler() throws IOException, InterruptedException {
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(5002, server);
        c1.startChatRoom();
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Socket socket1 = new Socket(IPAddress, 5002);
        Socket socket2 = new Socket(IPAddress, 5002);
        socket1.close();
        Thread.sleep(500);
        assertEquals(1, c1.getHandlers().size());
        socket1.close();
        socket2.close();
    }

    @Test
    public void acceptConnections() throws IOException, InterruptedException {
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(5003, server);
        c1.startChatRoom();
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Socket socket1 = new Socket(IPAddress, 5003);
        Socket socket2 = new Socket(IPAddress, 5003);
        Thread.sleep(500);
        assertEquals(2, c1.getHandlers().size());
        socket1.close();
        socket2.close();
    }

    @Test
    public void startChatRoom() throws InterruptedException {
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(5005, server);
        c1.startChatRoom();
        Thread.sleep(1000);
        assertEquals(Arrays.asList(c1), server.getChatRooms());
    }

    @Test
    public void stopChatRoom() throws IOException, InterruptedException {
        Server server = new Server();
        ChatRoom c1 = new ChatRoom(5001, server);
        c1.startChatRoom();
        InetAddress IPAddress = InetAddress.getByName("0.0.0.0");
        Socket socket1 = new Socket(IPAddress, 5001);
        Socket socket2 = new Socket(IPAddress, 5001);
        c1.stopChatRoom();
        Thread.sleep(500);
        assertEquals(0, c1.getHandlers().size());
        socket1.close();
        socket2.close();
    }
}