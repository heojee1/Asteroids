package server;

import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class ServerTest {

    @Test
    public void testAddChatRoom() {
        Server server = new Server();
        ChatRoom chatRoom1 = new ChatRoom(5001, server);
        ChatRoom chatRoom2 = new ChatRoom(5002, server);
        server.addChatRoom(chatRoom1);
        server.addChatRoom(chatRoom2);
        assertEquals(Arrays.asList(chatRoom1, chatRoom2), server.getChatRooms());
    }

    @Test
    public void testRemoveChatRoom() {
        Server server = new Server();
        ChatRoom chatRoom1 = new ChatRoom(5001, server);
        ChatRoom chatRoom2 = new ChatRoom(5002, server);
        server.addChatRoom(chatRoom1);
        server.addChatRoom(chatRoom2);
        server.removeChatRoom(chatRoom1);
        assertEquals(Arrays.asList(chatRoom2), server.getChatRooms());
    }


    @Test
    public void testStartServer() {
        Server server = new Server();
        server.startServer();
        assertEquals(4, server.getChatRooms().size());
    }
}