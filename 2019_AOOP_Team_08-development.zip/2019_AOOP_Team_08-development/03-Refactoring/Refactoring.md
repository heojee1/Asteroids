# Assignment 3 - Refactoring

For this assignment you will be refactoring one of the following included projects: `Cats`, `Chat`, or `Factory`. These are implementations of the projects you had the opportunity to submit as the second assignment. Please choose to refactor one of the included projects, but **not the one that you completed**. For example, if you were working on the `Cats` project a few weeks ago, then you may not refactor the included `Cats` implementation.

## Getting Started in Github

**Important:** Once you've chosen the project you will be refactoring, place
the content of the corresponding folder (containing `pom.xml` and at least the
`src` folder) in the main directory for this third assignment (`03-Refactoring`). That way it's clear to you, us, and CircleCi where we can find your project, as well as eliminating noise from other
projects sitting around doing nothing.

Afterwards, your repository should look something like this (in this example I chose the `Cats` project):

```
/.circleci
/01-IntSet
/02-Chat-Cats-Factory
/03-Refactoring
  /src
  Cats.pdf
  pom.xml
  Refactoring.md
.gitignore
```

## What's Expected of You?

While there is no exhaustive list of every conceivable thing you could do to make each project objectively better, there are a few things that we're especially going to look for:

- Tests
- Comments and Javadoc
- Class / Package Structure and Organization
- Method Length - If a method is longer than about 15 lines, then you'd better have a very good reason for keeping it there.
- Variable and Method Naming
- Modernization - Make use of Java 8's functional language constructs to simplify things.

Additionally, along with actually doing the refactoring, we would like for you to provide a concise overview of the refactorings you've made. This can be done by including a simple `readme.md` markdown file, a `.txt` file (as long as it's readable), PDF, or HTML or anything else that's readable by a human, with your submission pull request.

## Final Notes

For details on refactoring, check the lecture slides, or have a look at [this article](https://dzone.com/articles/what-is-refactoring) from DZone which can be a handy resource. If you need any further help, please open an issue in your repository.

Good luck!
