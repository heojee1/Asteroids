package model;

import java.io.Serializable;

/**
 * Address holds information of IP address and port number
 */
public class Address implements Serializable{
	private static final long serialVersionUID = 1L;
	private String name;
	private int port;

	/**
	 * creates a new Address object
	 *
	 * @param name IP address
	 * @param port port number
	 */
	public Address(String name, int port) {
		this.name = name;
		this.port = port;
	}

	/**
	 * getter for name
	 *
	 * @return String name
	 */
	public String getName() {
		return name;
	}

	/**
	 * getter for port
	 *
	 * @return int port
	 */
	public int getPort() {
		return port;
	}


	/**
	 * checks if the address and the given object has same fields
	 *
	 * @param obj the other object to be compared with
	 * @return returns true if the other object has the same name and port
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Address) {
			Address address = (Address) obj;
			return (name.equals(address.getName()) && port == address.getPort());
		}
		return false;
	}


	@Override
	public String toString() {
		return name + ":" + port;
	}
}
