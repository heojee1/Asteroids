package model;

import view.BoxView;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Observable;

/**
 * Box contains cats and random killswitch
 */
public class Box extends Observable implements Runnable {
	private static final double KILLSWiTCH_PROB = 0.8;
	private long name;
	private int capacity;
	private List<Address> boxAddresses;
	private List<Cat> cats;
	private Address address;
	private ServerSocket serverSocket;
	private Socket clientSocket;
	private boolean running;

	/**
	 * creates a new Box object
	 * @param capacity the maximum population of Cats
	 * @param address address (IP,port) of Box
	 */
	public Box(int capacity, Address address) {
		if(capacity < 0) throw new IllegalArgumentException("Capacity has to be positive");
		this.name = System.nanoTime() % 1000;
		this.capacity = capacity;
		this.address = address;
		this.boxAddresses = new ArrayList<>();
		this.cats = new ArrayList<>();
		this.running = false;
		new BoxView(this);

		if(BoxManager.debug_mode) System.out.println(this + " started at " + address);
		updateObservers();
	}

	/**
	 * drive code of the thread
	 */
	@Override
	public void run() {
		running = true;
		try {
			while(running) {
				acceptConnection();
				acceptInput();
				closeConnection();
				randomKillswitch();
			}
		} catch (Exception e) {
			System.err.println("Receiving command failed");
			e.printStackTrace();
		}
	}

	/**
	 * assigns a new SeverSocket to serverSocket
	 * accepts a new clientSocket
	 */
	private void acceptConnection() throws IOException {
		serverSocket = new ServerSocket(address.getPort());
		clientSocket = serverSocket.accept();
	}

	/**
	 * closes serverSocket and clientSocket
	 *
	 * @throws IOException in case of IO exceptions
	 */
	private void closeConnection() throws IOException {
		serverSocket.close();
		clientSocket.close();
	}

	/**
	 * accepts input from clientSocket
	 * accepted object can be : Cat, BoxMap, or command from BoxManager
	 *
	 * @throws IOException in case of IO exceptions
	 */
	public void acceptInput() throws IOException {
		try {
			ObjectInputStream objectInputStream = new ObjectInputStream(clientSocket.getInputStream());
			Object obj = objectInputStream.readObject();
			if (obj instanceof Cat) receiveCat(obj);
			else if (obj instanceof List) boxAddresses = (List)obj;
			else if (obj instanceof String) executeCommand(obj);
		} catch (ClassNotFoundException e) {
			System.err.println("Command not recognized");
		}
	}

	/**
	 * add given object to List cats
	 *
	 * @param obj object to be added
	 */
	public void receiveCat(Object obj) {
		Cat cat = (Cat)obj;
		try{
			addCat(cat);
		} catch (ArrayIndexOutOfBoundsException e) {
			if(BoxManager.debug_mode) System.out.println(cat + " died after teleporting because the box is full");
		}
	}

	/**
	 * executes the command of the given object
	 *
	 * @param obj the command
	 */
	public void executeCommand(Object obj) {
		String command = (String)obj;
		switch (command) {
			case "killall":
				killAllCats();
				break;
			case "stop":
				stopBox();
				break;
			case "openboxes":
				openBoxes();
				break;
			default:
				System.err.println("Command not recognized");
		}
	}

	/**
	 * kills all cat and stops the thread
	 */
	public void stopBox() {
		killAllCats();
		openBoxes();
		running = false;
		boxAddresses = null;
	}

	/**
	 * randomly activate killswitch with probability
	 */
	public void randomKillswitch() {
		if (Math.random() > KILLSWiTCH_PROB) {
			killAllCats();
			if (BoxManager.debug_mode) System.out.println(this + " triggers killswitch");
		}
	}

	/**
	 * kills all cats in the Box
	 */
	public void killAllCats() {
		for(Cat c : cats) {
			c.kill();
		}
		updateObservers();
	}

	/**
	 * remove dead cats, reset living cats to 9 lives
 	 */
	public void openBoxes() {
		Iterator<Cat> iter = cats.iterator();
		while(iter.hasNext()) {
			Cat c = iter.next();
			if(c.getAlive()) {
				c.revive();
			} else {
				System.out.println("Dead cat " + c + " removed from box " + this);
				iter.remove();
			}
		}
		updateObservers();
	}


	/**
	 * adds new cat to the Box if possible, throws exception otherwise
	 *
	 * @param cat new cat to be added
	 */
	public void addCat(Cat cat) {
		if(cats.size()+1 > capacity) throw new ArrayIndexOutOfBoundsException("Box is full");
		cats.add(cat);
		cat.setBox(this);
		cat.start();
		updateObservers();
	}

	/**
	 * removes given cat from the Box
	 *
	 * @param cat a cat to be removed
	 */
	public void removeCat(Cat cat) {
		cats.remove(cat);
		updateObservers();
	}

	/**
	 * getter for cats
	 *
	 * @return List cats
	 */
	public List<Cat> getCats() {
		return cats;
	}

	/**
	 * stringbuilder, for loop, synchronized
	 * @return
	 * TODO: move this to BoxView
	 */
	public String getCatListing() {
		StringBuilder sb = new StringBuilder();
		String info;
		for(int i = 0; i < this.cats.size(); i++) {
			Cat cat = this.cats.get(i);
			if (!cat.getAlive()) {
				 info = cat + " (dead)\n";
			} else {
				info =  cat + " (" + cat.getLives() + " lives, " + cat.getBattery() + "% battery)\n";
			}
			sb.append(info);
		}
		return sb.toString();
	}

	public List<Address> getBoxAddresses() {
		return boxAddresses;
	}

	/**
	 * getter for address
	 *
	 * @return Address address
	 */
	public Address getAddress() {
		return address;
	}

	/**
	 * getter for capacity
	 *
	 * @return int capacity
	 */
	public int getCapacity() {
		return capacity;
	}

	/**
	 * getter for running
	 *
	 * @return Boolean running
	 */
	public Boolean isRunning() {
		return running;
	}

	/**
	 * notifies changes to observers
	 */
	private void updateObservers() {
		setChanged();
		notifyObservers();
	}

	@Override
	public String toString() {
		return "Box" + name;
	}

	/**
	 * Usage:
	 * Box <capacity><port>
	 */
	public static void main (String [] args) {
		if (args.length >= 2) {
			try {
				int CAPACITY = Integer.parseInt(args[0]);
				Address ADDRESS = new Address(Inet4Address.getLocalHost().getHostAddress(), Integer.parseInt(args[1]));

				Box box = new Box(CAPACITY, ADDRESS);
				new Thread(box).start();
			} catch (NumberFormatException e) {
				System.err.println("Usage: java Box <capacity> <address> <port>");
				System.exit(1);
			} catch (UnknownHostException e) {
				System.err.println("Making Inet4Address failed");
				System.exit(1);
			}
		} else {
			System.err.println("Usage: java Box <capacity> <port>");
			System.exit(1);
		}
	}
}
