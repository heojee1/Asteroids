package model;

import view.BoxManagerView;
import utilities.Utility;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.UnknownHostException;
import java.util.*;

/**
 * BoxManager watches cats, randomly opens boxes, and adds cats
 */
public class BoxManager extends Observable implements Runnable {
	public static boolean debug_mode = true;
	private static final double OPEN_BOX_CHANCE = 0.6;
	private static final int MAX_NEW_CATS = 7;
	private String name;
	private List<Address> boxAddresses;
	private Random rand;
	private static int CAPACITY;

	/**
	 * creates a new BoxManager object
	 *
	 * @param name of the manager
	 */
	public BoxManager(String name) {
		this.name = name;
		this.boxAddresses = new ArrayList<>();
		new BoxManagerView(this);
		rand = new Random();
		if(BoxManager.debug_mode) System.out.println(this + " started");
		updateObservers();
	}

	/**
	 * drive code of the thread
	 */
	@Override
	public void run() {
		try	{
			while(true) {
				if (Math.random() < OPEN_BOX_CHANCE) {
					watchCats();
				} else {
					int randomIndex = rand.nextInt(boxAddresses.size());
					openBoxes(boxAddresses.get(randomIndex));
				}
			}
	    } catch (Exception e) {
	         System.err.println("opening boxes failed");
	    }

	}

	/**
	 * manager is in idle mode. pauses the thread for 4000ms
	 */
	private void watchCats() throws InterruptedException {
		if (BoxManager.debug_mode) System.out.println(this + " watches cats purring (4000ms)");
		Thread.sleep(4000);
	}

	/**
	 * add a new box address to List boxAddresses
	 *
	 * @param a new address to be added
	 */
	public void addBox(Address a) {
		System.out.println("adding boxes");
		for(Address address : boxAddresses) {
			if (address.equals(a)) return;
		}
		boxAddresses.add(a);
		sendBoxAddresses(boxAddresses);
		updateObservers();
	}

	/**
	 * Starts a new box using the button on the manager view
	 *
	 * @param address address of a new Box
	 */
	public void startBox(Address address) {
		Box box = new Box(CAPACITY, address);
		new Thread(box).start();
		addBox(box.getAddress());
	}

	/**
	 * removes box address from List boxAddresses
	 *
	 * @param a box address to be deleted
	 */
	public void removeBox(Address a) {
		Iterator<Address> iter = boxAddresses.iterator();
		while(iter.hasNext()) {
			Address address = iter.next();
			if (address.equals(a)) {
				sendCommand("stop", a);
				iter.remove();
			}
			sendBoxAddresses(boxAddresses);
			updateObservers();
		}
	}

	/**
	 * removes box address of given index from List boxAddresses
	 *
	 * @param i an index of boxAddresses to be deleted
	 */
	public void removeBox(int i) {
		boxAddresses.remove(i);
	}

	/**
	 * Sets all cats in the box to have 9 lives, removes dead cats, and randomly add new cats
	 *
	 * @param address address of the box to be opened
	 */
	public void openBoxes(Address address) {
		if (BoxManager.debug_mode) System.out.println(this + " is opening boxes");
		sendCommand("openboxes", address);
		int num = rand.nextInt(MAX_NEW_CATS);
		sendCats(boxAddresses, num);
	}

	/**
	 * send command to kill all cats of given address
	 *
	 * @param address address of target box
	 */
	public void killAll(Address address) {
		sendCommand("killall", address);
	}

	/**
	 * send command to kill all cats of box at given index
	 *
	 * @param index index of box at List boxAddresses
	 */
	public void killAll(int index) {
		sendCommand("killall", boxAddresses.get(index));
	}

	/**
	 * Sends a command (in string form) to a box
	 *
	 * @param command a command to be ordered
	 * @param address address of target box
	 */
	private void sendCommand(String command, Address address) {
		try {
			Utility.sendObject(command, address);
		} catch (IOException e) {
			System.err.println("Sending command to " + address + " failed");
			e.printStackTrace();
		}
	}

	/**
	 * getter for boxAddresses
	 *
	 * @return List boxAddresses
	 */
	public List<Address> getBoxAddresses() {
		return boxAddresses;
	}

	/**
	 *
	 * @return
	 */
	public String getBoxListing() {
		StringBuilder sb = new StringBuilder();
		for(int i = 0; i < boxAddresses.size(); i++) {
			Address a = boxAddresses.get(i);
			sb.append(a).append("\n");
		}
		return sb.toString();
	}

	/**
	 * Send list of available boxes to all boxes
	 *
	 * @param list list of box address to be sent over
	 */
	private static void sendBoxAddresses(List<Address> list) {
		System.out.println("sending maps");
		Iterator<Address> iter = list.iterator();
		while(iter.hasNext()) {
			try {
				Address address = iter.next();
				Utility.sendObject(list, address);
			} catch (IOException e) {
				System.err.println("Sending BoxMap to failed");
				e.printStackTrace();			}
		}
	}

	/**
	 * add new cat to box with given address
	 *
	 * @param address address of destination box
	 */
	private static void sendCat(Address address) {
		try {
			Utility.sendObject(new Cat(), address);
		} catch (IOException e) {
			System.out.println("A new cat died while teleporting to " + address);
		}
	}

	/**
	 * send given number of cats to random boxes
	 *
	 * @param list list of box addresses
	 * @param num number of cats to be sent over
	 */
	private static void sendCats(List<Address> list, int num) {
		System.out.println("sending cats");
		Random rand = new Random();
		while(num>0) {
			num--;
			Address address = list.get(rand.nextInt(list.size()));
			sendCat(address);
		}
	}

	/**
	 * notifies changes to observers
	 */
	private void updateObservers() {
		setChanged();
		notifyObservers();
	}

	@Override
	public String toString() {
		return "Manager " + name;
	}

	/**
	 * Usage:
	 * java BoxManager									(defaults to 2 boxes and cats)
	 * java BoxManager <boxes> <cats>					(defaults to capacity = 5)
	 * java BoxManager <boxes> <cats> <box_capacity>
	 */
	
	public static void main (String [] args) {	
		int NUM_BOXES = 2;
		int NUM_CATS = 2;
		CAPACITY = 5;

		if (args.length >= 2) {
			try {
	            NUM_BOXES = Integer.parseInt(args[0]);
	            NUM_CATS = Integer.parseInt(args[1]);
	            if (args.length >= 3) CAPACITY = Integer.parseInt(args[2]);
			} catch (NumberFormatException e) {
				System.err.println("The argument is not a number");
				System.exit(1);
			}
        }

		BoxManager manager = new BoxManager("Schrödinger");
		new Thread(manager).start();

		for(int i = 0; i < NUM_BOXES; i++) {
			try {
				Box box = new Box(CAPACITY, new Address(Inet4Address.getLocalHost().getHostAddress(), 9000+i));
				new Thread(box).start();
				Thread.sleep(500);
				manager.addBox(box.getAddress());
			} catch (UnknownHostException e) {
				System.err.println("Unable to automatically get an ip address");
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		sendCats(manager.getBoxAddresses(), NUM_CATS);
	}
}
