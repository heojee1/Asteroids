package model;

import utilities.Utility;

import java.io.IOException;
import java.io.Serializable;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.ReentrantLock;

public class Cat extends Thread implements Serializable {
	private static final long serialVersionUID = 1L;
	private static final double CLONE_CHANCE = 0.2;
	private static final double PURR_CHANCE = 0.4;
	private long name;
	private boolean alive;
	private int lives;
	private ReentrantLock lives_lock;
	private transient Box box;
	private Random rand;
	private int battery;

	/**
	 * creates a new default Cat object
	 */
	public Cat() {
		this(9, 100);
	}

	/**
	 * creates a new Cat object
	 * @param lives number of lives
	 * @param battery amount of battery of current life
	 */
	public Cat(int lives, int battery) {
		this.name = System.nanoTime() % 1000;
		this.lives = lives;
		this.alive = true;
		this.battery = battery;
		rand = new Random();
		lives_lock = new ReentrantLock();
		if(BoxManager.debug_mode) System.out.println(this + " started");
	}

	/**
	 * drive code of the thread
	 */
	@Override
	public void run() {
		while(alive) {
			chooseRandomAction();
		}
	}

	/**
	 * chooses randomly with probability, among cloning, purring, and teleporting
	 */
	private void chooseRandomAction() {
		double chance = Math.random();
		if (chance < CLONE_CHANCE) cloneCat();
		else if (chance < CLONE_CHANCE+PURR_CHANCE) purr();
		else teleport();
	}

	/**
	 * creates a new cat in the same box, with the same parameters
	 */
	public void cloneCat() {
		if(BoxManager.debug_mode) System.out.println(this + " clones itself");
		try {
			box.addCat(new Cat(lives, battery));
			updateBattery();
		} catch (ArrayIndexOutOfBoundsException e) {
			if(BoxManager.debug_mode) System.out.println(this + " failed to clone because the box is full");
		}
	}

	/**
	 * pauses the thread for a random amount of time
	 */
	public void purr() {
		int sleepTime = rand.nextInt(2000)+2000;
		try {
			updateBattery();
			if(BoxManager.debug_mode) System.out.println(this + " purrs in " + box + " (" + sleepTime + "s)");
			Thread.sleep(sleepTime);	
		} catch(Exception e) {
			System.err.println(this + " died while purring");
			kill();
		}
	}

	/**
	 * pauses the thread for a given amount of time
	 *
	 * @param sleepTime length of time to be paused
	 */
	public void purr(int sleepTime) {
		try {
			updateBattery();
			if(BoxManager.debug_mode)  System.out.println(this + " purrs in " + box + " (" + sleepTime + "s)");
			Thread.sleep(100);
		} catch (InterruptedException e) {
			System.err.println(this + " died while waiting for a teleport");
			this.kill();
		}
	}

	/**
	 * removes cat from current box, sends cat to random other box
	 */
	public void teleport() {
		List<Address> boxes = box.getBoxAddresses();
		if(boxes.size() > 0) {
			Address newBox;
			do {
				newBox = boxes.get(rand.nextInt(boxes.size()));
			} while (box.getAddress().equals(newBox));
			
			updateBattery();
			moveTo(newBox);
			kill();
			box.removeCat(this);
			if(BoxManager.debug_mode)  System.out.println(this + " teleports from " + box + " to " + newBox);
		} else {
			purr(100);
		}
	}


	/**
	 * sends a copy of a cat to a given address
	 *
	 * @param address destination address
	 */
	public void moveTo(Address address) {
		decrementLives();
		try {
			Utility.sendObject(this, address);
		} catch (IOException e) {
			System.out.println(this + " died while teleporting to " + address);
		}
	}

	/**
	 * sets alive to false
	 */
	public void kill() {
		lives_lock.lock();
		try {
			alive = false;
		} finally {
			lives_lock.unlock();
		}
	}

	/**
	 * restores number of lives to 9
	 */
	public void revive() {
		lives_lock.lock();
		try {
			lives = 9;
		} finally {
			lives_lock.unlock();
		}
	}

	/**
	 * takes away one life
	 */
	public void decrementLives() {
		lives_lock.lock();
		try {
			lives--;
		} finally {
			lives_lock.unlock();
		}
		if(lives <= 0) kill();
	}

	/**
	 * decrement battery and recharge the battery at the cost of a life
 	 */
	private void updateBattery() {
		battery = Math.max(0, battery-15);
		if (battery <= 0) {
			decrementLives();
			battery = 100;
		}
	}

	/**
	 * setter for Box box
	 *
	 * @param box new Box to be set to
	 */
	public void setBox(Box box) {
		this.box = box;
		if(BoxManager.debug_mode) System.out.println(this + " is now in " + box);
	}

	/**
	 * getter for alive
	 *
	 * @return Boolean alive
	 */
	public boolean getAlive() {
		return alive;
	}

	/**
	 * getter for lives
	 *
	 * @return int lives
	 */
	public int getLives() {
		return lives;
	}

	/**
	 * getter for battery
	 *
	 * @return int battery
	 */
	public int getBattery() {
		return battery;
	}

	@Override
	public String toString() {
		return  "Cat" + name;
	}
}
