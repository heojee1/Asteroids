package utilities;


import model.Address;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Utility contains static methods that are shared by different classes
 */
public class Utility {

    /**
     * sends an object to given address
     *
     * @param obj object to send to destination address
     * @param address destination address
     * @throws IOException when error rise while connecting socket or sending object
     */
    public static void sendObject(Object obj, Address address) throws IOException {
        String serverAddress = address.getName();
        int serverPort = address.getPort();
        Socket clientSocket = new Socket(serverAddress, serverPort);
        ObjectOutputStream oos = new ObjectOutputStream(clientSocket.getOutputStream());
        oos.writeObject(obj);
        oos.flush();
        oos.close();
        clientSocket.close();
    }

    /**
     * set up the frame and displays it on window
     *
     * @param frame frame that will show display
     */
    public static void initUI(JFrame frame) {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setPreferredSize(new Dimension(300, 300));
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.Y_AXIS));
    }

    /**
     * set up label of with given text and adds it on given pane
     *
     * @param pane pane that will show display
     * @param label label that will be modified
     * @param text text that will appear on label
     */
    public static void makeLabel(Container pane, JLabel label, String text) {
        label.setText(text);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        pane.add(label);
    }

    /**
     * displays a given JTextPane and adds it on given pane
     *
     * @param pane pane that will show display
     * @param listing listing whose contents will be displayed
     */
    public static void makeListing(Container pane, JTextPane listing) {
        JScrollPane list = new JScrollPane();
        list.setAlignmentX(Component.CENTER_ALIGNMENT);

        listing.setEditable(false);
        list.setViewportView(listing);

        pane.add(list);
    }

    /**
     * prompts a input dialog and receives address of a box
     *
     * @param message message that appears on input dialog
     * @return String[] with
     * @throws NullPointerException
     */
    public static String[] getInputBoxAddress(String message) throws NullPointerException {
        String input;
        do {
            input = JOptionPane.showInputDialog(message, "Format = address:port");
        } while (!input.contains(":"));
        return input.split(":");
    }

}
