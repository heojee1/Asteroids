package view;

import model.Address;
import model.BoxManager;
import utilities.Utility;

import javax.swing.*;
import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * BoxManagerView displays a view of its BoxManager model
 */
public class BoxManagerView extends JFrame implements Observer {
	private static final long serialVersionUID = 1L;
	public BoxManager manager;
	private JTextPane boxListing;
	private JLabel boxLabel;

	/**
	 * creates a new BoxManagerView object
	 *
	 * @param manager model to be displayed
	 */
	public BoxManagerView(BoxManager manager) {
		super(manager.toString());
		this.manager = manager;
		manager.addObserver(this);
		setComponents();
		Utility.initUI(this);
	}

	/**
	 * add components to the pane
	 */
	private void setComponents() {
		boxLabel = new JLabel();
		Utility.makeLabel(getContentPane(), boxLabel, "Known boxes:");
				
		boxListing = new JTextPane();
		Utility.makeListing(getContentPane(), boxListing);

		addNewBoxButton();
		addRemoveBoxButton();
		addExterminateButton();
	}

	/**
	 * create and add button that starts a new box
	 */
	private void addNewBoxButton() {
		JButton newBoxButton = new JButton("Add new box");
		newBoxButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		newBoxButton.addActionListener(arg0 -> {
			try {
				String[] boxAddress = Utility.getInputBoxAddress("Give the ip-address and port number of the box");
				String serverAddress = boxAddress[0];
				int serverPort = Integer.parseInt(boxAddress[1]);
				manager.startBox(new Address(serverAddress, serverPort));
			} catch (NullPointerException e) {
				// Adding box aborted by user
			} catch (NumberFormatException e) {
				System.err.println("Argument wrong, insert an integer for the port");
			}
		});
		getContentPane().add(newBoxButton);
	}

	/**
	 * create and add button that removes a box
	 */
	private void addRemoveBoxButton() {
		JButton removeBoxButton = new JButton("Remove box");
		removeBoxButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		removeBoxButton.addActionListener(arg0 -> {
			try {
				String[] boxAddress = Utility.getInputBoxAddress("Give the ip-address and port number or number of the box");
				if (boxAddress.length == 2) {
					String serverAddress = boxAddress[0];
					int serverPort = Integer.parseInt(boxAddress[1]);
					manager.removeBox(new Address(serverAddress, serverPort));
				} else {
					int boxNumber = Integer.parseInt(boxAddress[0]);
					if (boxNumber < manager.getBoxAddresses().size()) manager.removeBox(boxNumber);
				}
			} catch (NullPointerException e) {
				// Removing box aborted by user
			} catch (NumberFormatException e) {
				System.err.println("Argument wrong, insert an integer");
			}
		});
		getContentPane().add(removeBoxButton);
	}

	/**
	 * create and add button that kills all cat in a box
	 */
	private void addExterminateButton() {
		JButton exterminateButton = new JButton("Exterminate box");
		exterminateButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		exterminateButton.addActionListener(arg0 -> {
			try {
				String[] boxAddress = Utility.getInputBoxAddress("Give the ip-address and port number or number of the box");
				if (boxAddress.length == 2) {
					String serverAddress = boxAddress[0];
					int serverPort = Integer.parseInt(boxAddress[1]);
					manager.killAll(new Address(serverAddress, serverPort));
				} else {
					int boxNumber = Integer.parseInt(boxAddress[0]);
					if (boxNumber < manager.getBoxAddresses().size()) manager.killAll(boxNumber);
				}
			} catch (NullPointerException e) {
				// Removing box aborted by user
			} catch (NumberFormatException e) {
				System.err.println("Argument wrong, insert an integer");
			}
		});
		getContentPane().add(exterminateButton);
	}

	@Override
	public void update(Observable o, Object arg) {
		boxLabel.setText("Known boxes (" + manager.getBoxAddresses().size() + "):");
		boxListing.setText(manager.getBoxListing());
	}
}
