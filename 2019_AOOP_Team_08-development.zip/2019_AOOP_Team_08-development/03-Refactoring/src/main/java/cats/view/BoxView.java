package view;

import model.Box;
import model.Cat;
import utilities.Utility;

import javax.swing.*;
import java.awt.*;
import java.util.Observable;
import java.util.Observer;

/**
 * BoxView displays a view of its Box model
 */
public class BoxView extends JFrame implements Observer {
	private static final long serialVersionUID = 1L;
	private Box model;
	private JTextPane catsListing;
	private JLabel capacityLabel;
	private JLabel catsLabel;

	/**
	 * creates a new BoxView
	 *
	 * @param box model to be displayed
	 */
	public BoxView(Box box) {
		setTitle(box.toString());
		this.model = box;
		model.addObserver(this);
		setComponents();
		Utility.initUI(this);
	}

	/**
	 * add components to the pane
	 */
	private void setComponents() {
		addLabels();
		addCatListing();
		addCatButton();
		addOpenBoxButton();
	}

	/**
	 * create and add labels
	 */
	private void addLabels() {
		JLabel addressLabel = new JLabel();
		Utility.makeLabel(getContentPane(), addressLabel, "Box address: " + model.getAddress());

		capacityLabel = new JLabel();
		Utility.makeLabel(getContentPane(), capacityLabel, "Capacity:");

		catsLabel = new JLabel();
		Utility.makeLabel(getContentPane(), catsLabel, "Cats:");
	}

	/**
	 * create and add catListing
	 */
	private void addCatListing() {
		catsListing = new JTextPane();
		Utility.makeListing(getContentPane(), catsListing);
	}

	/**
	 * create and add button that adds a new cat to the box
	 */
	private void addCatButton() {
		JButton newCatButton = new JButton("Add new cat");
		newCatButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		newCatButton.addActionListener(arg0 -> {
			try {
				if(model.isRunning())
					model.addCat(new Cat());
				else
					System.err.println("Box is not running");
			} catch (ArrayIndexOutOfBoundsException e) {
				System.err.println("Box is full, no cat added");
			}
		});
		getContentPane().add(newCatButton);
	}

	/**
	 * create and add button that opens the box
	 */
	private void addOpenBoxButton() {
		JButton openBoxButton = new JButton("Open boxes");
		openBoxButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		openBoxButton.addActionListener(arg0 -> model.openBoxes());
		getContentPane().add(openBoxButton);
	}

	@Override
	public void update(Observable o, Object arg) {
		capacityLabel.setText("Capacity: " + model.getCapacity());
		catsLabel.setText("Cats (" + model.getCats().size() + "):");
		catsListing.setText(model.getCatListing());

	}
}
