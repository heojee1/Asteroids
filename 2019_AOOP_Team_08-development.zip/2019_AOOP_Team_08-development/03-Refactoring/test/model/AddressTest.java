package model;

import org.junit.Test;

import java.net.Inet4Address;
import java.net.UnknownHostException;

import static org.junit.Assert.*;

public class AddressTest {

    @Test
    public void testEquals() throws UnknownHostException {
        final int PORT = 9000;
        Address address1 = new Address(Inet4Address.getLocalHost().getHostAddress(), PORT);
        Address address2 = new Address(Inet4Address.getLocalHost().getHostAddress(), PORT);
        Address address3 = new Address(Inet4Address.getLocalHost().getHostAddress(), PORT + 1);
        Address address4 = new Address("address 3", PORT);
        Address address5 = new Address("address 5", PORT + 1);

        assertEquals(address1, address2);
        assertNotEquals(address1, address3);
        assertNotEquals(address1, address4);
        assertNotEquals(address1, address5);
    }
}