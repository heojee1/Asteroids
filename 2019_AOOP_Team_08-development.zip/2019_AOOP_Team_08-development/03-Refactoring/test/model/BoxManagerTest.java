package model;

import org.junit.Test;

import java.net.Inet4Address;
import java.net.UnknownHostException;

import static org.junit.Assert.*;

public class BoxManagerTest {

    @Test
    public void testAddBox() throws UnknownHostException, InterruptedException {
        BoxManager manager = new BoxManager("A");
        Box box = new Box(5, new Address(Inet4Address.getLocalHost().getHostAddress(), 9000));
        new Thread(box).start();
        Thread.sleep(500);
        manager.addBox(box.getAddress());

        assertEquals(1, manager.getBoxAddresses().size());
    }

    @Test
    public void testStartBox() throws UnknownHostException, InterruptedException {
        BoxManager manager = new BoxManager("A");
        Box box = new Box(5, new Address(Inet4Address.getLocalHost().getHostAddress(), 9000));
        new Thread(box).start();
        Thread.sleep(500);
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9007);
        manager.startBox(address);

        assertEquals(1, manager.getBoxAddresses().size());

    }

    @Test
    public void testRemoveBox() throws InterruptedException, UnknownHostException {
        BoxManager manager = new BoxManager("A");
        Box box1 = new Box(5, new Address(Inet4Address.getLocalHost().getHostAddress(), 9000));
        Box box2 = new Box(5, new Address(Inet4Address.getLocalHost().getHostAddress(), 9001));
        new Thread(box1).start();
        Thread.sleep(500);
        new Thread(box2).start();
        Thread.sleep(500);
        manager.addBox(box1.getAddress());
        manager.addBox(box2.getAddress());
        manager.removeBox(box1.getAddress());

        assertEquals(1, manager.getBoxAddresses().size());
        assertEquals(0, manager.getBoxAddresses().size());
    }

    @Test
    public void testRemoveBox1() throws UnknownHostException, InterruptedException {
        BoxManager manager = new BoxManager("A");
        Box box = new Box(5, new Address(Inet4Address.getLocalHost().getHostAddress(), 9000));
        new Thread(box).start();
        Thread.sleep(500);
        manager.addBox(box.getAddress());
        manager.removeBox(0);

        assertEquals(0, manager.getBoxAddresses().size());
    }
}