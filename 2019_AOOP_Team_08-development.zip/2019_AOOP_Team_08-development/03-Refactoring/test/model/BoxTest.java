package model;

import org.junit.Before;
import org.junit.Test;
import utilities.Utility;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

public class BoxTest {

    @Test
    synchronized public void testRun() throws IOException, InterruptedException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9000);
        Box box = new Box(5, address);
        List<Address> boxAddresses = new ArrayList<>();
        Address address1 = new Address("address 1", 9001);
        Address address2 = new Address("address 2", 9002);
        boxAddresses.add(address1);
        boxAddresses.add(address2);

        new Thread(box).start();
        Thread.sleep(500);

        Utility.sendObject(new Cat(), address);
        Thread.sleep(500);
        assertEquals(1, box.getCats().size());

        Utility.sendObject(boxAddresses, address);
        Thread.sleep(500);
        assertEquals(Arrays.asList(address1, address2), box.getBoxAddresses());

        Utility.sendObject("killall", address);
        Thread.sleep(500);
        assertFalse(box.getCats().get(0).getAlive());

    }

    @Test
    synchronized public void testReceiveCat() throws IOException, InterruptedException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9003);
        Box box = new Box(5, address);
        new Thread(box).start();
        Thread.sleep(500);

        Utility.sendObject(new Cat(), address);
        Thread.sleep(500);

        assertEquals(1, box.getCats().size());
    }

    @Test
    synchronized public void testStopBox() throws UnknownHostException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9004);
        Box box = new Box(5, address);
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        box.addCat(cat1);
        box.addCat(cat2);
        box.stopBox();

        assertEquals(0, box.getCats().size());
        assertFalse(box.isRunning());
        assertNull(box.getBoxAddresses());
    }

    @Test
    synchronized public void testKillAllCats() throws UnknownHostException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9005);
        Box box = new Box(5, address);
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        box.addCat(cat1);
        box.addCat(cat2);
        box.killAllCats();

        assertFalse(cat1.getAlive());
        assertFalse(cat2.getAlive());

    }

    @Test
    synchronized public void testOpenBoxes() throws UnknownHostException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9006);
        Box box = new Box(5, address);
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        Cat cat3 = new Cat();
        box.getCats().add(cat1);
        box.getCats().add(cat2);
        box.getCats().add(cat3);
        cat1.kill();
        cat2.decrementLives();
        cat3.kill();
        box.openBoxes();

        assertEquals(Arrays.asList(cat2), box.getCats());
        assertEquals(9, cat2.getLives());
    }

    @Test
    synchronized public void testAddCat() throws UnknownHostException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9007);
        Box box = new Box(2, address);
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        box.addCat(cat1);
        box.addCat(cat2);

        assertEquals(2, box.getCats().size());
    }

    @Test (expected = ArrayIndexOutOfBoundsException.class)
    synchronized public void testAddCatOverLimit() throws UnknownHostException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9008);
        Box box = new Box(1, address);
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        box.addCat(cat1);
        box.addCat(cat2);
    }

    @Test
    synchronized public void testRemoveCat() throws UnknownHostException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9009);
        Box box = new Box(2, address);
        Cat cat1 = new Cat();
        Cat cat2 = new Cat();
        box.addCat(cat1);
        box.addCat(cat2);
        box.removeCat(cat2);

        assertEquals(1, box.getCats().size());
    }
}