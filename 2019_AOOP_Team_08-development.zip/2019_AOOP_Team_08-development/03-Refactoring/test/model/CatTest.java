package model;

import org.junit.Test;
import utilities.Utility;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.UnknownHostException;

import static org.junit.Assert.*;

public class CatTest {


    @Test
    public void testKill() {
        Cat cat = new Cat();
        cat.kill();
        assertFalse(cat.getAlive());
    }

    @Test
    public void testRevive() {
        Cat cat = new Cat();
        cat.decrementLives();
        cat.revive();
        assertEquals(9, cat.getLives());
    }

    @Test
    public void testDecrementLives() {
        Cat cat = new Cat();
        cat.decrementLives();
        cat.decrementLives();
        assertEquals(7, cat.getLives());
    }
}