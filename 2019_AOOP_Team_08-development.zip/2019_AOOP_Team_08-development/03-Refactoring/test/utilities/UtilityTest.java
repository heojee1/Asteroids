package utilities;

import model.Address;
import org.junit.Test;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;

import static org.junit.Assert.*;

public class UtilityTest {

    @Test
    public void sendObject() throws IOException, ClassNotFoundException {
        Address address = new Address(Inet4Address.getLocalHost().getHostAddress(), 9000);
        ServerSocket serverSocket = new ServerSocket(9000);

        Utility.sendObject("this is message", address);

        Socket clientSocket = serverSocket.accept();
        ObjectInputStream inputStream = new ObjectInputStream(clientSocket.getInputStream());
        Object obj = inputStream.readObject();

        assertTrue(obj instanceof String);
        assertEquals("this is message", obj);


    }
}